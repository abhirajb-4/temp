package com.example.trainer.controller;

public class TrainerController {
}
