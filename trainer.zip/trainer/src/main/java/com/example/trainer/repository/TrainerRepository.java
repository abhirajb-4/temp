package com.example.trainer.repository;

public interface TrainerRepository {
}
