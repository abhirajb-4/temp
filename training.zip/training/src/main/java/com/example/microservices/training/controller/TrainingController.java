package com.example.microservices.training.controller;

import com.example.microservices.training.model.Training;
import com.example.microservices.training.service.TrainingService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/training")
public class TrainingController {

    private final TrainingService trainingService;

    public TrainingController(TrainingService trainingService){
        this.trainingService = trainingService;
    }

    @PostMapping
    public ResponseEntity<Training> createTraining(@RequestBody Training training){
        Training savedTraining = trainingService.createTraining(training);
        return ResponseEntity.ok(savedTraining);
    }

    @GetMapping
    public List<Training> getAllTraining(){
        return trainingService.getAllTraining();
    }
    @GetMapping("/{id}")
    public ResponseEntity<Training> getTrainingById(@PathVariable Long id) {
        Optional<Training> training = trainingService.getTrainingById(id);
        return training.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }


    @GetMapping("/organization/{organizationName}")
    public List<Training> getTrainingsByOrganization(@PathVariable String organizationName) {
        return trainingService.getTrainingsByOrganization(organizationName);
    }



    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteTraining(@PathVariable Long id) {
        trainingService.deleteTraining(id);
        return ResponseEntity.noContent().build();
    }

}
