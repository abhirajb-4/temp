package com.example.microservices.training.model;

public enum DurationUnit {
    HOURS,DAYS,MONTHS
}
