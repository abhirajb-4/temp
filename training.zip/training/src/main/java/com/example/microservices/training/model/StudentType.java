package com.example.microservices.training.model;

public enum StudentType {
    FRESHER,LATERAL
}
