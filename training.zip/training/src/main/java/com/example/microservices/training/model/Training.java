package com.example.microservices.training.model;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;
import java.util.List;

@Entity
@Data
@Getter
@Setter
@AllArgsConstructor
@SequenceGenerator(name = "training_seq", sequenceName = "training_seq", initialValue = 10000, allocationSize = 1)
public class Training {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "training_seq")
    private Long id;

    private String name;
    private String organizationName;

    @ElementCollection
    @CollectionTable(name = "training_skills", joinColumns = @JoinColumn(name = "training_id"))
    @Column(name = "skill")
    private List<String> skills;

    @Enumerated(EnumType.STRING)
    private DurationUnit durationUnit;
    private int durationValue;
    private LocalDate startDate;
    private LocalDate endDate;
    private int noOfStudents;
    private int noOfBatches;
    private int budget;
    private String toc;
    private String poc;
    private String email;
    private long phno;
    @Enumerated(EnumType.STRING)
    private StudentType studentType;

}
