package com.example.microservices.training.repository;

import com.example.microservices.training.model.Training;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface TrainingRepository extends JpaRepository<Training,Long> {
    //Get Trainings by Organization name
    List<Training> findByOrganizationName(String organizationName);

    // Get Trainings by start date
    List<Training> findByStartDate(LocalDate startDate);
}
