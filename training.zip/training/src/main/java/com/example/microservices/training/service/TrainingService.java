package com.example.microservices.training.service;

import com.example.microservices.training.exception.InvalidDateException;
import com.example.microservices.training.model.Training;
import com.example.microservices.training.repository.TrainingRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class TrainingService {
    private final TrainingRepository trainingRepository;

    public TrainingService(TrainingRepository trainingRepository) {

        this.trainingRepository = trainingRepository;
    }

    public Training createTraining(Training training) {
        if (training.getName()== null || training.getName().isEmpty()) {
            throw new IllegalArgumentException("Training name cannot be null or empty");
        }
        //Date validation
        if(training.getStartDate().isAfter(training.getEndDate())){
            throw new InvalidDateException("Start date is greater than end date");
        }

        return trainingRepository.save(training);
    }

    public List<Training> getAllTraining() {
        return trainingRepository.findAll();
    }

    public Optional<Training> getTrainingById(Long id) {
        return trainingRepository.findById(id);
    }

    public List<Training> getTrainingsByOrganization(String organizationName) {
        return trainingRepository.findByOrganizationName(organizationName);
    }


    public void deleteTraining(Long id) {
        trainingRepository.deleteById(id);
    }
}
